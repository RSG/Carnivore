MAC

This version is Intel and PowerPC compatible.

Java 1.6 is required. Use "Software Update" to install all Java and Mac
system updates. Use the command `java -version` to make sure you have
version 1.6.

Note: you must do this Terminal command each time you restart your mac:

	sudo chmod 777 /dev/bpf*

+ + +

WINDOWS

Java 1.6 is required. Use the command `java -version` to make sure you
have version 1.6.

Winpcap (www.winpcap.org) is required.

+ + +

Linux

We've tested on Ubuntu and gotten everything working. Read the support
threads for more info..
